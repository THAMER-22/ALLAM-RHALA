from utils.helper_rahaala import *
from utils.rahaala_prompt import get_documents


# Interactive Q&A loop using Pinecone and IBM Watson Allam model
def qa_system(query,index,embedding_tokenizer, embedding_model, all_chunks, processed_data):
    print("مرحبًا بك في نظام الأسئلة والأجوبة. اكتب 'خروج' لإنهاء الجلسة.")

    #while True:
        #query = input("أدخل سؤالك: ")
    
    if query.lower() == "خروج":
        return "شكرًا لاستخدامك النظام!"

    # Query Pinecone for relevant documents
    relevant_docs = query_pinecone(query,index,embedding_tokenizer, embedding_model, all_chunks)

    # Combine the query and retrieved documents for context
    context = f"سؤال: {query}\n\nالمعلومات ذات الصلة:\n" + "\n\n".join(relevant_docs)

    # Generate a response using the Allam model
    response = plan_trip(query, processed_data)
    return response

if __name__ == "__main__":
    index,embedding_tokenizer, embedding_model, all_chunks = add_doc_into_database(get_documents())
    processed_data = get_processed_data()
    print('Documented Added') 

    query = "ايش ابرز الاشياء الموجودة في العلا"
    response = qa_system(query,index,embedding_tokenizer, embedding_model, all_chunks,processed_data)
    print("الجواب:", response)
