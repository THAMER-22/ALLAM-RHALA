# import sys
# import os
# # Add the utils directory to the system path
# sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), 'src/utils')))
from utils.utils import *
from utils.prompt_document import get_documents


# Main function to automate the entire process
def automate_llm_to_speech(audio_file_path,index,embedding_tokenizer, embedding_model,all_chunks,output_audio):
    # Step 1: Transcribe audio to text using Whisper
    user_question = transcribe_audio_to_text(audio_file_path)
    print("Transcribed Text:", user_question)

    # Step 2: Query Pinecone for relevant documents
    relevant_docs = query_pinecone(user_question,index,embedding_tokenizer, embedding_model,all_chunks)
    context = f"سؤال: {user_question}\n\nالمعلومات ذات الصلة:\n" + "\n\n".join(relevant_docs)

    # Step 3: Generate LLM response using Allam model
    llm_output = generate_response_with_allam(context)

    print("LLM Output:", llm_output)

    # Step 4: Convert LLM output to speech using Eleven Labs
    process_with_tts(llm_output,output_audio)  # Add TTS process here

if __name__ == "__main__":
    index,embedding_tokenizer, embedding_model, all_chunks = add_doc_into_database(get_documents())
    input_audio = 'sample/WhatsApp Audio 2024-11-04 at 2.24.58 AM.mp4'
    output_audio = 'sample/llm_output_speech.mp3'
    automate_llm_to_speech(input_audio,index,embedding_tokenizer, embedding_model,all_chunks,output_audio)
