import re
import torch
import pinecone
from transformers import AutoTokenizer, AutoModel
import nltk
from nltk.corpus import stopwords
from ibm_watsonx_ai.foundation_models import Model
import getpass
from pinecone import Pinecone, ServerlessSpec
from tqdm  import tqdm
from utils.rahaala_prompt import system_instructions
from utils.rahaala_prompt import get_documents
import os
from dotenv import load_dotenv

load_dotenv()


# Download NLTK stopwords if not already downloaded
nltk.download('stopwords')

# Arabic stopwords from NLTK
arabic_stopwords = set(stopwords.words('arabic'))


# Function to split text into smaller chunks
def split_text_into_chunks(text, max_length=128):
    words = text.split()
    chunks = []
    current_chunk = []
    current_length = 0
    for word in words:
        current_chunk.append(word)
        current_length += 1
        if current_length >= max_length:
            chunks.append(' '.join(current_chunk))
            current_chunk = []
            current_length = 0
    if current_chunk:
        chunks.append(' '.join(current_chunk))
    return chunks


# clean and normalize Arabic text
def clean_arabic_text(text):
    text = re.sub(r'[إأآا]', 'ا', text)
    text = re.sub(r'ؤ', 'و', text)
    text = re.sub(r'ئ', 'ي', text)
    text = re.sub(r'ى', 'ي', text)
    text = re.sub(r'ة', 'ه', text)
    text = re.sub(r'[\u0617-\u061A\u064B-\u0652]', '', text)
    text = re.sub(r'[^\u0600-\u06FF\s]', '', text)
    text = re.sub(r'\s+', ' ', text).strip()
    return text

# Function to remove stopwords from Arabic text
def remove_stopwords(text):
    tokens = text.split()
    tokens = [word for word in tokens if word not in arabic_stopwords]
    return ' '.join(tokens)

# Full cleaning process for text
def full_cleaning_process(text):
    cleaned_text = clean_arabic_text(text)
    final_text = remove_stopwords(cleaned_text)
    return final_text

# Function to generate response using Allam model
def generate_response_with_allam(context):
    model = initialize_model()

    # Combine system instructions and context
    prompt = system_instructions() + "\n\n" + context + "\n\nالجواب:"

    # Ensure the prompt is not empty before sending to the model
    if not prompt.strip():
        raise ValueError("The prompt for the model cannot be empty.")

    # Ensure prompt is within the token limit
    max_prompt_length = 2000 - model.params["max_new_tokens"]
    prompt_tokens = len(prompt.split())
    if prompt_tokens > max_prompt_length:
        # Truncate the prompt to fit within the token limit
        prompt = ' '.join(prompt.split()[-max_prompt_length:])

    # Generate response
    response = model.generate_text(prompt=prompt, params=model.params, guardrails=False)

    # The response is the generated text
    generated_text = response.strip()

    return generated_text

def plan_multi_day_trip_as_ibn_battuta(query, extracted_data):
    recommendations = []
    budgets = []  # List to store valid budgets
    num_days = 1  # Default to one day

    # Determine number of days from the query
    if 'يومين' in query:
        num_days = 2
    elif 'ثلاثة أيام' in query:
        num_days = 3
    elif 'أربع أيام' in query or 'أربعة أيام' in query:
        num_days = 4
    elif 'أسبوع' in query:
        num_days = 7

    # Selecting hotels, activities, and restaurants
    selected_hotels = []
    selected_activities = []
    selected_restaurants = []

    for entry in extracted_data:
        if entry['التصنيف'] == 'فندق' and len(selected_hotels) < num_days:
            selected_hotels.append(entry)
        elif entry['التصنيف'] == 'المغامرات' and len(selected_activities) < num_days:
            selected_activities.append(entry)
        elif entry['التصنيف'] == 'مطعم' and len(selected_restaurants) < num_days:
            selected_restaurants.append(entry)

        if len(selected_hotels) == num_days and len(selected_activities) == num_days and len(selected_restaurants) == num_days:
            break

    # Create the response if enough selections are made
    if len(selected_hotels) == num_days and len(selected_activities) == num_days and len(selected_restaurants) == num_days:
        context = "أهلاً بك يا صاحب الرحلة، سأأخذك في رحلة إلى مدينة العلا الساحرة لمدة " + str(num_days) + " أيام."

        for day in range(num_days):
            context += f"\n\nفي اليوم {day + 1}:"
            context += f"\n- الإقامة: {selected_hotels[day]['اسم']}. {selected_hotels[day]['الوصف']}"
            context += f"\n- النشاط: {selected_activities[day]['اسم']}. {selected_activities[day]['الوصف']}"
            context += f"\n- المطعم: {selected_restaurants[day]['اسم']}. {selected_restaurants[day]['الوصف']}"

            # Extract budgets for each day
            for budget_item in [selected_hotels[day]['السعر'], selected_activities[day]['السعر'], selected_restaurants[day]['السعر']]:
                if budget_item is not None:  # Check if the price is not None
                    budgets.append(float(budget_item))
        
        # Calculate the total budget ignoring N/A values
        total_budget = sum(budgets)

        if budgets:
            context += f"\n\nبالنسبة للميزانية، فإن التكلفة المقدرة لهذه الرحلة هي {total_budget} ريال سعودي."
        else:
            context += "\n\nبالنسبة للميزانية، فإن التكلفة المقدرة لهذه الرحلة هي N/A ريال سعودي."

        response = generate_response_with_allam(context)
        return response
    else:
        return "عذرًا، لم أتمكن من تجميع معلومات كافية لتخطيط رحلة لمدة أكثر من يوم."

def plan_single_day_trip(query, extracted_data):
    context = "أهلاً بك يا صاحب الرحلة، سأقدم لك خطة سفر ليوم واحد في العلا."
    selected_hotel = None
    selected_activity = None
    selected_restaurant = None
    budgets = []  # List to store valid budgets

    for entry in extracted_data:
        if entry['التصنيف'] == 'فندق' and selected_hotel is None:
            selected_hotel = entry
        elif entry['التصنيف'] == 'المغامرات' and selected_activity is None:
            selected_activity = entry
        elif entry['التصنيف'] == 'مطعم' and selected_restaurant is None:
            selected_restaurant = entry
        
        if selected_hotel and selected_activity and selected_restaurant:
            break

    if selected_hotel and selected_activity and selected_restaurant:
        context += f"\n- الإقامة: {selected_hotel['اسم']}. {selected_hotel['الوصف']}"
        context += f"\n- النشاط: {selected_activity['اسم']}. {selected_activity['الوصف']}"
        context += f"\n- المطعم: {selected_restaurant['اسم']}. {selected_restaurant['الوصف']}"

        # Collect budgets
        budgets = []
        for budget_item in [selected_hotel['السعر'], selected_activity['السعر'], selected_restaurant['السعر']]:
            if budget_item is not None:  # Check if the price is not None
                budgets.append(float(budget_item))

        total_budget = sum(budgets)

        if budgets:
            context += f"\n\nبالنسبة للميزانية، فإن التكلفة المقدرة لهذه الرحلة هي {total_budget} ريال سعودي."
        else:
            context += "\n\nبالنسبة للميزانية، فإن التكلفة المقدرة لهذه الرحلة هي N/A ريال سعودي."

        response = generate_response_with_allam(context)
        return response
    else:
        return "عذرًا، لم أتمكن من تجميع معلومات كافية لتخطيط رحلة ليوم واحد."


    
    
# Final function to handle both single-day and multi-day trip requests
def plan_trip(query, processed_data):
    keywords = ['خطة', 'رحلة', 'أنشطة', 'فعاليات', 'سفرة', 'مدة', 'خطط', 'ضع مخطط', 'إقامة', 
                'برنامج سياحي', 'جدول زمني', 'زيارة', 'استكشاف', 'تراث', 'ثقافة', 'مغامرة', 
                'فنادق', 'مطاعم', 'إرشادات', 'الفعاليات', 'الزيارات']
    
    # Check for the presence of keywords in the query
    if any(keyword in query for keyword in keywords):
        if 'يومين' in query or 'ثلاثة أيام' in query or 'أربع أيام' in query or 'أسبوع' in query or 'أيام' in query:
            return plan_multi_day_trip_as_ibn_battuta(query, processed_data)
        else:
            return plan_single_day_trip(query, processed_data)
    else:
        # Use the existing function to generate a response
        context = f"سؤال: {query}\n\n"
        return generate_response_with_allam(context)



# Main function to handle the user's query
def handle_trip_query(query, extracted_data):
    # Check for multi-day trip keywords
    if any(keyword in query.lower() for keyword in ['يومين', 'ثلاثة أيام', 'أربع أيام', 'أسبوع', 'أيام']):
        return plan_multi_day_trip_as_ibn_battuta(query, processed_data)
    else:
        return plan_single_day_trip(query, processed_data)


def format_price(price_str):
    """ Convert price from string to float, return None for 'N/A' or empty strings """
    if 'ابتداءً من' in price_str:
        price = re.findall(r'\d+', price_str)
        return float(price[0].replace(',', '')) if price else None
    return None

def process_data(data):
    """ Process the extracted data into a more usable format """
    processed_data = []
    for item in data:
        formatted_price = format_price(item['السعر'])
        # Include only relevant items (exclude items with 'N/A' prices)
        if formatted_price is not None or item['السعر'] == '':
            processed_data.append({
                'التصنيف': item['التصنيف'],
                'اسم': item['اسم'],
                'المدة الزمنية': item['المدة الزمنية'],
                'الوصف': item['الوصف'],
                'السعر': formatted_price
            })
    return processed_data

# Example of filtering recommendations based on user interest
def get_recommendations(processed_data, category):
    """ Get recommendations based on the specified category """
    return [item for item in processed_data if item['التصنيف'] == category]


import requests
from bs4 import BeautifulSoup

def get_processed_data():
    # URL of the page to scrape
    urls = ["https://www.experiencealula.com/ar/about/about-alula/history-and-heritage", "https://www.experiencealula.com/ar/about/about-alula/adventure",
           "https://www.experiencealula.com/ar/about/about-alula/wellness"]
    # List to hold extracted data
    extracted_data = []
    for url in urls:
        # Send a request to the website
        response = requests.get(url)
        # Check if the request was successful
        if response.status_code == 200:
            print("Page successfully retrieved.")
            
            # Parse the HTML content
            soup = BeautifulSoup(response.text, 'html.parser')

            # Find all activity cards
            activity_cards = soup.find_all("div", class_="product-card itinerary-card d-flex flex-column")
            # Loop through each activity card
            for card in activity_cards:
                # Extract category text
                category_tag = card.find("div", class_="category tags")
                category_name = category_tag.text.strip() if category_tag else "N/A"
            
                # Extract the title
                title_tag = card.find("span", class_="title")
                title = title_tag.text.strip() if title_tag else "N/A"
            
                # Extract duration
                duration_tag = card.find("div", class_="duration tags")
                duration = duration_tag.find("span", class_="duration").text.strip() if duration_tag else "N/A"
            
                # Extract description
                description = card.find("p", class_="card-text").text.strip() if card.find("p", class_="card-text") else "N/A"
            
                # Extract price information
                price_info_tag = card.find("p", class_="price-info body-semi-bold")
                price_info = price_info_tag.text.strip() if price_info_tag else "N/A"
                # Store the results in a dictionary
                extracted_data.append({
                    'التصنيف': category_name,
                    'اسم': title,
                    'المدة الزمنية': duration,
                    'الوصف': description,
                    'السعر': price_info
                })
        
        # Print the extracted data
        for data in extracted_data:
            print(f"تصنيف الفعالية: {data['التصنيف']}, اسم الفعالية: {data['اسم']}, مدة الفعالية: {data['المدة الزمنية']}, الوصف: {data['الوصف']}, السعر: {data['السعر']}")
    else:
        print("Failed to retrieve the page.")
    processed_data = process_data(extracted_data)

    return processed_data



def get_credentials():
    return {
        "url": os.getenv('IBM_MODEL_URL'),
        "apikey": os.getenv('IBM_MODEL_API')
    }

# Initialize IBM Watson Allam Arabic model
def initialize_model():
    parameters = {
        "decoding_method": "greedy",
        "max_new_tokens": 1536,
        "repetition_penalty": 1.05
    }

    model_id = os.getenv('IBM_MODEL_ID')
    project_id = os.getenv('IBM_MODEL_PID')

    model = Model(
        model_id=model_id,
        params=parameters,
        credentials=get_credentials(),
        project_id=project_id
    )
    return model

 

# Updated function to query Pinecone for relevant documents
def query_pinecone(query_text,index,embedding_tokenizer, embedding_model, all_chunks):
    # Clean and embed the query text
    cleaned_query = full_cleaning_process(query_text)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    query_embedding = get_embedding(cleaned_query,embedding_tokenizer,embedding_model,device).cpu().numpy().tolist()

    # Query Pinecone for the top 3 most relevant documents
    query_results = index.query(vector=query_embedding, top_k=3)

    # Retrieve the document IDs from the search results
    document_ids = [match['id'] for match in query_results['matches']]

    documents = get_documents()

    # Fetch the corresponding documents
    relevant_docs = [documents[int(doc_id.split('_')[1])] for doc_id in document_ids]

    return relevant_docs

# Function to get embeddings from the model
def get_embedding(text,embedding_tokenizer,embedding_model,device):
    inputs = embedding_tokenizer(text, return_tensors="pt", truncation=True, padding=True)
    inputs = {key: value.to(device) for key, value in inputs.items()}

    with torch.no_grad():
        embeddings = embedding_model(**inputs).last_hidden_state.mean(dim=1)
    return embeddings

def add_doc_into_database(documents):

    # Clean and normalize the documents
    cleaned_documents = [full_cleaning_process(doc) for doc in documents]

    # Split documents into chunks
    all_chunks = []
    for idx, doc in enumerate(cleaned_documents):
        chunks = split_text_into_chunks(doc, max_length=128)  # Adjust max_length as needed
        for chunk_num, chunk in enumerate(chunks):
            all_chunks.append({
                'id': f'doc_{idx}_chunk_{chunk_num}',
                'text': chunk
            })

    # Load an Arabic pre-trained model for embedding (LaBSE)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    embedding_model_name = 'sentence-transformers/LaBSE'
    embedding_tokenizer = AutoTokenizer.from_pretrained(embedding_model_name)
    embedding_model = AutoModel.from_pretrained(embedding_model_name).to(device)


    # Generate embeddings for all chunks
    embeddings = []
    print("Generating embeddings for documents...")
    for chunk in tqdm(all_chunks):
        embedding = get_embedding(chunk['text'],embedding_tokenizer,embedding_model,device)
        embeddings.append(embedding)

    # Stack embeddings into a tensor
    document_embeddings = torch.vstack(embeddings)

    # Convert embeddings to NumPy array
    document_embeddings_numpy = document_embeddings.cpu().numpy()

    # Initialize Pinecone
    from pinecone import Pinecone, ServerlessSpec

    # Set your Pinecone API key directly in the code
    PINECONE_API_KEY = os.getenv('PINECONE_API_KEY')  # Replace with your Pinecone API key

    # Initialize Pinecone
    pc = Pinecone(api_key=PINECONE_API_KEY)

    # Create Pinecone index
    index_name = "th"
    if index_name not in pc.list_indexes().names():
        pc.create_index(
            name=index_name,
            dimension=document_embeddings_numpy.shape[1],
            metric='cosine',
            spec=ServerlessSpec(
                cloud='aws',
                region='us-east-1'
            )
        )
    # Connect to the Pinecone index
    index = pc.Index(index_name)

    # Insert document embeddings into Pinecone
    ids = [chunk['id'] for chunk in all_chunks]
    vectors_to_upsert = [(ids[i], document_embeddings_numpy[i].tolist()) for i in range(len(ids))]
    index.upsert(vectors=vectors_to_upsert)

    print(f"Inserted {len(ids)} documents into Pinecone.")
    return index, embedding_tokenizer, embedding_model,all_chunks