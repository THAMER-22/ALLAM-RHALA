import re
from typing import Dict, List, Optional
import random
import os
import requests
from bs4 import BeautifulSoup
import pandas as pd
from dotenv import load_dotenv
from ibm_watsonx_ai.foundation_models import Model
load_dotenv()


# URL of the page to scrape
urls = [
    "https://www.experiencealula.com/ar/about/about-alula/history-and-heritage",
    "https://www.experiencealula.com/ar/about/about-alula/adventure",
    "https://www.experiencealula.com/ar/about/about-alula/wellness"
]

def catogery_1(card,duration_tag,extracted_data,category_name):
    # Extract the title
    title_tag = card.find("span", class_="title")
    title = title_tag.text.strip() if title_tag else None

    # Extract duration
    type_tag = card.find("div", class_="duration tags")
    typet = type_tag.find("span", class_="duration").text.strip() if duration_tag else None

    # Extract description
    description = card.find("p", class_="card-text").text.strip() if card.find("p", class_="card-text") else None

    # Extract price information
    price_info_tag = card.find("p", class_="price-info body-semi-bold")
    price_info = price_info_tag.text.strip() if price_info_tag else None

    # Store the results in a dictionary
    extracted_data.append({
        'التصنيف': category_name,
        'اسم': title,
        'المدة الزمنية': None,
        'الوصف': typet,
        'السعر': price_info
    })
    return extracted_data


def scrap_data():
    extracted_data = []

    for url in urls:
        # Send a request to the website
        response = requests.get(url)
        # Check if the request was successful
        if response.status_code == 200:
            print("Page successfully retrieved.")

            # Parse the HTML content
            soup = BeautifulSoup(response.text, 'html.parser')

            # Find all activity cards
            activity_cards = soup.find_all("div", class_="product-card itinerary-card d-flex flex-column")
            # Loop through each activity card
            for card in activity_cards:
                # Extract category text
                category_tag = card.find("div", class_="category tags")
                category_name = category_tag.text.strip() if category_tag else None
                # if category_name == 'مطعم' or category_name == 'عربة طعام':
                #      catogery_1(card)
                #      continue

                # Extract the title
                title_tag = card.find("span", class_="title")
                title = title_tag.text.strip() if title_tag else None

                # Extract duration
                duration_tag = card.find("div", class_="duration tags")
                duration = duration_tag.find("span", class_="duration").text.strip() if duration_tag else None
                if category_name == 'مطعم' or category_name == 'عربة طعام':
                     catogery_1(card,duration_tag,extracted_data,category_name)
                     continue

                # Extract description
                description = card.find("p", class_="card-text").text.strip() if card.find("p", class_="card-text") else None

                # Extract price information
                price_info_tag = card.find("p", class_="price-info body-semi-bold")
                price_info = price_info_tag.text.strip() if price_info_tag else None

                # Store the results in a dictionary
                extracted_data.append({
                    'التصنيف': category_name,
                    'اسم': title,
                    'المدة الزمنية': duration,
                    'الوصف': description,
                    'السعر': price_info
                })
        else:
            print("Failed to retrieve the page.")
    # Convert the list of dictionaries to a DataFrame
    df = pd.DataFrame(extracted_data)

    # Export the DataFrame to an Excel file
    df.to_excel('alula_activities.xlsx', index=False)
    print("Data exported to alula_activities.xlsx successfully.")


class AlUlaTravelPlanner:
    def __init__(self, excel_file='alula_activities.xlsx'):
        self.data = pd.read_excel(excel_file)
        self.model = self._initialize_model()

    def get_credentials(self):
        return {
            "url": os.getenv('IBM_MODEL_URL'),
            "apikey": os.getenv('IBM_MODEL_API')
        }


    def _initialize_model(self):

        parameters = {
            "decoding_method": "greedy",
            "max_new_tokens": 1528,
            "min_new_tokens": 50,
            "temperature": 0.5,
            "repetition_penalty": 1.05
        }

        return Model(
            model_id=os.getenv('IBM_MODEL_ID'),
            credentials=self.get_credentials(),
            project_id=os.getenv('IBM_MODEL_PID'),
            params=parameters
        )

    def generate_trip_plan(self, query: str) -> str:
        days = 2 if "يومين" in query else 1
        people = 4 if "عائلة" in query else (2 if "شخصين" in query else 1)

        prompt = f"""
        أنت مخطط رحلات محترف للعلا. المطلوب تخطيط رحلة لمدة {days} يوم ل {people} أشخاص.
        يجب أن تكون الإجابة بالتنسيق التالي بالضبط:

        فعاليات اليوم 1:

        الصباح:
        - الفعالية: [اسم الفعالية]
        - الوصف: [وصف مختصر]
        - المدة: [المدة بالساعات أو الدقائق]
        - السعر: [السعر] ريال سعودي للشخص × {people} = [السعر الإجمالي] ريال سعودي

        وقت الغداء:
        - المطعم: [اسم المطعم]
        - نوع المطبخ: [نوع المطبخ]
        - السعر: [السعر] × {people} = [السعر الإجمالي] ريال سعودي

        بعد الظهر:
        - الفعالية: [اسم الفعالية]
        - الوصف: [وصف مختصر]
        - المدة: [المدة]
        - السعر: [السعر] ريال سعودي × {people} = [السعر الإجمالي] ريال سعودي

        إجمالي تكلفة اليوم 1: [المجموع] ريال سعودي

        {'''فعاليات اليوم 2:

        الصباح:
        - الفعالية: [اسم الفعالية]
        - الوصف: [وصف مختصر]
        - المدة: [المدة]
        - السعر: [السعر] ريال سعودي للشخص × {people} = [السعر الإجمالي] ريال سعودي

        وقت الغداء:
        - المطعم: [اسم المطعم]
        - نوع المطبخ: [نوع المطبخ]
        - السعر: [السعر] × {people} = [السعر الإجمالي] ريال سعودي

        بعد الظهر:
        - الفعالية: [اسم الفعالية]
        - الوصف: [وصف مختصر]
        - المدة: [المدة]
        - السعر: [السعر] ريال سعودي × {people} = [السعر الإجمالي] ريال سعودي

        إجمالي تكلفة اليوم 2: [المجموع] ريال سعودي''' if days > 1 else ''}

        إجمالي تكلفة الرحلة الكاملة: [المجموع الكلي] ريال سعودي

        ملاحظة: قم باختيار أنشطة وأماكن حقيقية من العلا، واحسب الأسعار بشكل منطقي.
        """

        response = self.model.generate_text(prompt=prompt)
        return response