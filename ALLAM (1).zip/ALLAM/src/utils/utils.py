import re
import torch
from transformers import AutoTokenizer, AutoModel
import nltk
from nltk.corpus import stopwords
from ibm_watsonx_ai.foundation_models import Model
import whisper  # For ASR
import requests  # For API calls
from tqdm import tqdm  # For progress bars
from utils.prompt_document import system_instructions
import os
from dotenv import load_dotenv

load_dotenv()

# Download NLTK stopwords if not already downloaded
nltk.download('stopwords')

# Arabic stopwords from NLTK
arabic_stopwords = set(stopwords.words('arabic'))

# Function to clean and normalize Arabic text
def clean_arabic_text(text):
    text = re.sub(r'[إأآا]', 'ا', text)
    text = re.sub(r'ؤ', 'و', text)
    text = re.sub(r'ئ', 'ي', text)
    text = re.sub(r'ى', 'ي', text)
    text = re.sub(r'ة', 'ه', text)
    text = re.sub(r'[\u0617-\u061A\u064B-\u0652]', '', text)  # Remove diacritics
    text = re.sub(r'[^\u0600-\u06FF\s]', '', text)  # Remove non-Arabic characters
    text = re.sub(r'\s+', ' ', text).strip()  # Remove extra spaces
    return text

# Function to remove stopwords from Arabic text
def remove_stopwords(text):
    tokens = text.split()
    tokens = [word for word in tokens if word not in arabic_stopwords]
    return ' '.join(tokens)

# Full cleaning process for text
def full_cleaning_process(text):
    cleaned_text = clean_arabic_text(text)
    final_text = remove_stopwords(cleaned_text)
    return final_text

# Function to split text into smaller chunks
def split_text_into_chunks(text, max_length=128):
    words = text.split()
    chunks = []
    current_chunk = []
    current_length = 0
    for word in words:
        current_chunk.append(word)
        current_length += 1
        if current_length >= max_length:
            chunks.append(' '.join(current_chunk))
            current_chunk = []
            current_length = 0
    if current_chunk:
        chunks.append(' '.join(current_chunk))
    return chunks

# Function to get embeddings from the model
def get_embedding(text,embedding_tokenizer,embedding_model,device):
    inputs = embedding_tokenizer(text, return_tensors="pt", truncation=True, padding=True)
    inputs = {key: value.to(device) for key, value in inputs.items()}

    with torch.no_grad():
        embeddings = embedding_model(**inputs).last_hidden_state.mean(dim=1)
    return embeddings

def get_credentials():
    return {
        "url": os.getenv('IBM_MODEL_URL'),
        "apikey": os.getenv('IBM_MODEL_API')
    }

# Initialize IBM Watson Allam Arabic model
def initialize_model():
    parameters = {
        "decoding_method": "greedy",
        "max_new_tokens": 1428,
        "repetition_penalty": 1.05
    }

    model_id = os.getenv('IBM_MODEL_ID')
    project_id = os.getenv('IBM_MODEL_PID')

    model = Model(
        model_id=model_id,
        params=parameters,
        credentials=get_credentials(),
        project_id=project_id
    )
    return model
  # Generate response using Allam model
def generate_response_with_allam(context):
    model = initialize_model()

    # Combine system instructions and context
    prompt = system_instructions() + "\n\n" + context + "\n\nالجواب:"

    # Ensure the prompt is not empty before sending to the model
    if not prompt.strip():
        raise ValueError("The prompt for the model cannot be empty.")

    # Ensure prompt is within the token limit
    max_prompt_length = 2000 - model.params["max_new_tokens"]
    prompt_tokens = len(prompt.split())
    if prompt_tokens > max_prompt_length:
        # Truncate the prompt to fit within the token limit
        prompt = ' '.join(prompt.split()[-max_prompt_length:])

    # Generate response
    response = model.generate_text(prompt=prompt, params=model.params, guardrails=False)

    # The response is the generated text
    generated_text = response.strip()

    return generated_text
# Whisper model initialization
def initialize_whisper():
    return whisper.load_model("base")  # Choose model size as needed

# Function to transcribe audio to text using Whisper
def transcribe_audio_to_text(audio_file_path):
    whisper_model = initialize_whisper()
    result = whisper_model.transcribe(audio_file_path, language='ar')
    return result['text']

# Function for Eleven Labs Text-to-Speech Integration
def text_to_speech_eleven_labs(text):
    api_key = os.getenv('ELVEN_API')  # Replace with your Eleven Labs API key
    voice_id = os.getenv('ELVEN_VID') # Replace with your desired voice ID
    url = f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}/stream"

    headers = {
        "xi-api-key": api_key,
        "Accept": "audio/mpeg",
        "Content-Type": "application/json"
    }

    data = {
        "text": text,
        "model_id": "eleven_multilingual_v2",
        "voice_settings": {
            "stability": 0.75,
            "similarity_boost": 0.75
        }
    }


    response = requests.post(url, json=data, headers=headers, stream=True)
    if response.status_code == 200:
        return response
    else:
        print("Error:", response.json())
        return None

# Function to download and save the audio file
def download_audio(response, filename="llm_output_speech.mp3"):
    try:
        with open(filename, 'wb') as f:
            for chunk in response.iter_content(chunk_size=1024):
                if chunk:
                    f.write(chunk)
        print(f"Audio file saved at: {filename}")
    except Exception as e:
        print("Error downloading audio:", str(e))

# Example usage with a generated response
def process_with_tts(generated_text,output_file):
    tts_response = text_to_speech_eleven_labs(generated_text)
    if tts_response:
        download_audio(tts_response, filename=output_file)


def add_doc_into_database(documents):

    
    # Clean and normalize the documents
    cleaned_documents = [full_cleaning_process(doc) for doc in documents]

    # Split documents into chunks
    all_chunks = []
    for idx, doc in enumerate(cleaned_documents):
        chunks = split_text_into_chunks(doc, max_length=128)  # Adjust max_length as needed
        for chunk_num, chunk in enumerate(chunks):
            all_chunks.append({
                'id': f'doc_{idx}_chunk_{chunk_num}',
                'text': chunk
            })

    # Load an Arabic pre-trained model for embedding (LaBSE)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    embedding_model_name = 'sentence-transformers/LaBSE'
    embedding_tokenizer = AutoTokenizer.from_pretrained(embedding_model_name)
    embedding_model = AutoModel.from_pretrained(embedding_model_name).to(device)


    # Generate embeddings for all chunks
    embeddings = []
    print("Generating embeddings for documents...")
    for chunk in tqdm(all_chunks):
        embedding = get_embedding(chunk['text'],embedding_tokenizer,embedding_model,device)
        embeddings.append(embedding)

    # Stack embeddings into a tensor
    document_embeddings = torch.vstack(embeddings)

    # Convert embeddings to NumPy array
    document_embeddings_numpy = document_embeddings.cpu().numpy()

    # Initialize Pinecone
    from pinecone import Pinecone, ServerlessSpec

    # Set your Pinecone API key directly in the code
    PINECONE_API_KEY = os.getenv('PINECONE_API_KEY')  # Replace with your Pinecone API key

    # Initialize Pinecone
    pc = Pinecone(api_key=PINECONE_API_KEY)

    # Create Pinecone index
    index_name = "th"
    if index_name not in pc.list_indexes().names():
        pc.create_index(
            name=index_name,
            dimension=document_embeddings_numpy.shape[1],
            metric='cosine',
            spec=ServerlessSpec(
                cloud='aws',
                region='us-east-1'
            )
        )
    # Connect to the Pinecone index
    index = pc.Index(index_name)

    # Insert document embeddings into Pinecone
    ids = [chunk['id'] for chunk in all_chunks]
    vectors_to_upsert = [(ids[i], document_embeddings_numpy[i].tolist()) for i in range(len(ids))]
    index.upsert(vectors=vectors_to_upsert)

    print(f"Inserted {len(ids)} documents into Pinecone.")
    return index, embedding_tokenizer, embedding_model,all_chunks

# Function to query Pinecone for relevant documents
def query_pinecone(query_text, index, embedding_tokenizer, embedding_model, all_chunks, top_k=3):
    # Clean and embed the query text
    cleaned_query = full_cleaning_process(query_text)
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    query_embedding = get_embedding(cleaned_query,embedding_tokenizer, embedding_model,device).cpu().numpy().tolist()

    # Query Pinecone for the top k most relevant documents
    query_response = index.query(vector=query_embedding, top_k=top_k)

    # Retrieve the document IDs from the search results
    document_ids = [match['id'] for match in query_response['matches']]

    # Fetch the corresponding documents
    id_to_text = {chunk['id']: chunk['text'] for chunk in all_chunks}

    # Handle cases where the ID is not found
    relevant_docs = [id_to_text.get(doc_id, f"Document with ID {doc_id} not found.") for doc_id in document_ids]

    return relevant_docs
