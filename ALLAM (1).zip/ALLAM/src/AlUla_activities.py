 # First, install these packages using pip in your terminal:
# pip install requests beautifulsoup4 langchain transformers

import re
from typing import Dict, List, Optional
import random
from utils.AlUla import  *
import time
scrap_data()

def main():
    planner = AlUlaTravelPlanner()

    print("مرحباً بك في نظام تخطيط رحلات العلا!")
    print("يمكنني مساعدتك في تخطيط:")
    print("- رحلات ثقافية وتاريخية")
    print("- مغامرات وأنشطة رياضية")
    print("- رحلات استجمام واسترخاء")
    print("- رحلات عائلية")
    print("\nأمثلة على الأسئلة:")
    print("- أعطني خطة رحلة استجمام لعائلة مكونة من 4 أفراد")
    print("- خطط لي رحلة مغامرات ليومين لشخصين")
    print("- أريد رحلة ثقافية لثلاثة أيام")
    print("\nاكتب 'خروج' للإنهاء البرنامج.")
    print("-" * 50)

    while True:
        try:
            query = input("\nما هي الرحلة التي ترغب في تخطيطها؟ ")

            if query.lower() == 'خروج':
                print("شكراً لاستخدام نظام تخطيط رحلات العلا!")
                break
            start_time = time.time()

            print("\nجاري تخطيط رحلتك...")
            response = planner.generate_trip_plan(query)
            print("\nالخطة المقترحة:")
            print(response)
            print("\n" + "-" * 50)
            end_time = time.time()
            print(end_time-start_time)

        except Exception as e:
            print(f"عذراً، حدث خطأ غير متوقع: {str(e)}")
            print("يرجى المحاولة مرة أخرى.")

if __name__ == "__main__":
    try:
       main()
    except KeyboardInterrupt:
       print("\nتم إنهاء البرنامج.")
    except Exception as e:
       print(f"\nحدث خطأ غير متوقع: {str(e)}")